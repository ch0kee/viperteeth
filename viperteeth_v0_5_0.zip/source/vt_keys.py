from key_codes import (\
EKeyUpArrow,
EKeyDownArrow,
EKeyLeftArrow,
EKeyRightArrow\
)
